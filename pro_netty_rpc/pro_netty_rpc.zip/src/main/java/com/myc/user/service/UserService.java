package com.myc.user.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.myc.user.bean.User;

@Service
public class UserService {

	public void save(User user) {
		// TODO Auto-generated method stub
		//访问Mysql
	}

	public void saveList(List<User> users) {
		// TODO Auto-generated method stub
		
	}

}
